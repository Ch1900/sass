Kernel.load File.join(File.dirname(__FILE__), '..', 'init.rb')
